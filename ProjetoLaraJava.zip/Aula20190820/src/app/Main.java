
package app;


public class Main {

    public static void main(String[] args) {
        
        Shampoo fabricante = new Shampoo("Pantene - Hidratacao");
        Shampoo fabricante2 = new Shampoo("Dove - Reconstrucao ") ;
        
        fabricante.menu(28, "plastica", "dove");

        

            
        fabricante.setNome("Pantene - Hidratacao");
        System.out.println(fabricante.getNome());
        //System.out.println(fabricante.getEstoqueDove());
        fabricante2.setNome("Dove - Reconstrucao");
        System.out.println(fabricante2.getNome());
        //fabricante.setEstoqueDove(100);
        
        
        fabricante.setEstoqueDove(80);
        System.out.println(fabricante.getEstoqueDove());
        System.out.println(fabricante.getEstoquePantene());
        fabricante.setEstoquePantene(80);
        System.out.println(fabricante.getEstoquePantene());
        fabricante.setEstoquePantene(120);
        System.out.println(fabricante.getEstoquePantene());
        
        System.out.println(fabricante2.getEstoqueDove());
        fabricante2.setEstoqueDove(50);
        System.out.println(fabricante2.getEstoqueDove());
        fabricante2.setEstoqueDove(30);
        System.out.println(fabricante2.getEstoqueDove()); 
       
        
        
        System.out.println("..|end application");
    
        


//MateriaPrima mp = new MateriaPrima("Laranja");
        
        

        
        
       /* System.out.println(mp.getEstoque());
       //mp.setEstoque(100);
       //System.out.println(mp.getEstoque());
       //mp.setEstoque(200);
        System.out.println(mp.getEstoque());
        
        
        //
        
        System.out.println(mp.getNome());
        System.out.println(mp.getEstoque());
        mp.setNome("Morango");
        System.out.println(mp.getNome());
        mp.setEstoque(100);
        mp.setNome("Banana");
        
        System.out.println(mp.getEstoque());
        mp.addQtd(20);
        System.out.println(mp.getEstoque());
        mp.addQtd(18);
        System.out.println(mp.getEstoque());
        mp.subQtd(25);
        System.out.println(mp.getEstoque());
      System.out.println("..|end application");
*/

   }
    
}
